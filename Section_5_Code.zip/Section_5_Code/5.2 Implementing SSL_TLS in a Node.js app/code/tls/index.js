const https = require('https');
const { readFileSync } = require('fs');
const credentials = {
  key: readFileSync('/etc/letsencrypt/live/learnobot.com/privkey.pem', 'utf-8'),
  cert: readFileSync('/etc/letsencrypt/live/learnobot.com/fullchain.pem', 'utf-8'),
  dhparam: readFileSync('/etc/letsencrypt/live/learnobot.com/dhkey.pem', 'utf-8')
}

module.exports = app => https.createServer(credentials, app);