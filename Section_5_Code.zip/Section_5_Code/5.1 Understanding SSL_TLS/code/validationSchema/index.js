module.exports = {
  formInput: { 
    in: 'body',
    escape: true
  }
};